export interface ErrorType {
    status: string;
    message: string
}