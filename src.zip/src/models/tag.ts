export type TagDataState = {
  tags: string[];
};
